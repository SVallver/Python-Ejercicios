import sqlite3

db_connection = sqlite3.connect('ej11.db')
db_cursor = db_connection.cursor()

db_cursor.execute("CREATE TABLE Alumnos(Id INT, Nombre TEXT, Apellido TEXT)")

db_cursor.execute("INSERT INTO Alumnos VALUES(1,'Sergio', 'Vallverdú')")
db_cursor.execute("INSERT INTO Alumnos VALUES(2,'Paula', 'Lopez')")
db_cursor.execute("INSERT INTO Alumnos VALUES(3,'Alex', 'Diaz')")
db_cursor.execute("INSERT INTO Alumnos VALUES(4,'Victoria', 'Sancho')")
db_cursor.execute("INSERT INTO Alumnos VALUES(5,'Mario', 'Alvarez')")
db_cursor.execute("INSERT INTO Alumnos VALUES(6,'Carla', 'Llorente')")
db_cursor.execute("INSERT INTO Alumnos VALUES(7,'Sergio', 'Roura')")
db_cursor.execute("INSERT INTO Alumnos VALUES(8,'Gabriel', 'Yañez')")

db_connection.commit()

db_cursor.execute("SELECT * FROM Alumnos WHERE Nombre = 'Victoria'")

filas = db_cursor.fetchall()

print(filas)

db_connection.close()